<?php

namespace ContainerU4zEjNc;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder14fcd = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer03832 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties71702 = [
        
    ];

    public function getConnection()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getConnection', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getMetadataFactory', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getExpressionBuilder', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'beginTransaction', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getCache', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getCache();
    }

    public function transactional($func)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'transactional', array('func' => $func), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'wrapInTransaction', array('func' => $func), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'commit', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->commit();
    }

    public function rollback()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'rollback', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getClassMetadata', array('className' => $className), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'createQuery', array('dql' => $dql), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'createNamedQuery', array('name' => $name), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'createQueryBuilder', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'flush', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'clear', array('entityName' => $entityName), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->clear($entityName);
    }

    public function close()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'close', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->close();
    }

    public function persist($entity)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'persist', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'remove', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'refresh', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'detach', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'merge', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getRepository', array('entityName' => $entityName), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'contains', array('entity' => $entity), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getEventManager', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getConfiguration', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'isOpen', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getUnitOfWork', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getProxyFactory', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'initializeObject', array('obj' => $obj), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'getFilters', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'isFiltersStateClean', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'hasFilters', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return $this->valueHolder14fcd->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer03832 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder14fcd) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder14fcd = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder14fcd->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, '__get', ['name' => $name], $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        if (isset(self::$publicProperties71702[$name])) {
            return $this->valueHolder14fcd->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder14fcd;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder14fcd;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder14fcd;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder14fcd;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, '__isset', array('name' => $name), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder14fcd;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder14fcd;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, '__unset', array('name' => $name), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder14fcd;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder14fcd;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, '__clone', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        $this->valueHolder14fcd = clone $this->valueHolder14fcd;
    }

    public function __sleep()
    {
        $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, '__sleep', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;

        return array('valueHolder14fcd');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer03832 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer03832;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer03832 && ($this->initializer03832->__invoke($valueHolder14fcd, $this, 'initializeProxy', array(), $this->initializer03832) || 1) && $this->valueHolder14fcd = $valueHolder14fcd;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder14fcd;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder14fcd;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
