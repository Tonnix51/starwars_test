<?php

namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\HttpClientInterface;

/**
 * Class IndexController
 * @package App\Controller
 */
class IndexController extends AbstractController
{
    /**
     * @Route("/", name="homepage")
     * @param Request $request
     * @param HttpClientInterface $client
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function index(Request $request, HttpClientInterface $client)
    {
        $results = [];
        $filter = false;
        $defaultData = ['message' => 'message par defaut'];
        $form = $this->createFormBuilder($defaultData)
            ->add('search', TextType::class, ['label' => false])
            ->add('filter', ChoiceType::class, [
                'label' => false,
                'choices' => [
                    'Personnage' => 'people',
                    'Vaisseaux' => 'starships',
                    'Planètes' => 'planets',
                    'Films' => 'films',
                    'Véhicules' => 'vehicles',
                    'Espèces' => 'species',
                ],
                'expanded' => true,
                'multiple' => false,
                'data' => 'people'
            ])
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $search = $form->get('search')->getData();
            $filter = $form->get('filter')->getData();
            $results = $this->fetchSwapiInfo($client, $filter, $search);
        }
        return $this->render('index.html.twig', [
            'title' => 'starwars',
            'searchForm' => $form->createView(),
            'type' => $filter,
            'results' => $results
        ]);
    }

    /**
     * @param $client
     * @param $type
     * @param $search
     * @return array
     */
    private function fetchSwapiInfo($client, $type, $search): array
    {
        if (empty($type)){
            $url = 'https://swapi.dev/api/people/?search=' . $search;
        }
        $url = 'https://swapi.dev/api/' . $type . '/?search=' . $search;

        $response = $client->request(
            'GET',
            $url
        );
        $content = $response->getContent();
        $content = $response->toArray();
        return $content['results'];
    }
}